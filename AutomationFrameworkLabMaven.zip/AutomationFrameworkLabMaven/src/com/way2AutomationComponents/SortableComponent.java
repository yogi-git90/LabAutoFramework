package com.way2AutomationComponents;

public class SortableComponent {

}
