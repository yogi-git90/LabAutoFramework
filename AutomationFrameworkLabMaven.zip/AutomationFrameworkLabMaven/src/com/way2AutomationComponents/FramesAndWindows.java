package com.way2AutomationComponents;

public class FramesAndWindows {

}
