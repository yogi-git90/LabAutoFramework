package com.AjaxForms;

public class TestAjax {

	public static void main(String[] args) {
	String url = "http://www.ajaxformpro.com/preview/";

	}

}
